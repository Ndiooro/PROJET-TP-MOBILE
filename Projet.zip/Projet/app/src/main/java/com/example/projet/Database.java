package com.example.projet;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class Database extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "article_database";
    private static final int DATABASE_VERSION = 1;

    private Context context;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase article_database) {

        // Creation de la table des articles
        String createTableArticle = "CREATE TABLE articles (" +
                "idArticles INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT NOT NULL," +
                "content TEXT NOT NULL," +
                "author TEXT NOT NULL," +
                "date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP" +
                ")";
        article_database.execSQL(createTableArticle);

    }

    @Override
    public void onUpgrade(SQLiteDatabase article_database, int i, int DATABASE_VERSION) {
        article_database.execSQL("DROP TABLE IF EXISTS articles;");
        onCreate(article_database);

    }

    public void addArticle(Article article) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("title", article.getTitle());
        values.put("content", article.getContent());
        values.put("author", article.getAuthor());
        //values.put("DATE", article.getDate().toString());

        db.insert("articles", null, values);
        db.close();
    }
    public List<Article> getAllArticles() {
        List<Article> articleList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {"idArticles","title", "content"};
        Cursor cursor = db.query("articles", columns, null, null, null, null, null);

        while (cursor.moveToNext()) {
            @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex("title"));
            @SuppressLint("Range") String idArticles = cursor.getString(cursor.getColumnIndex("idArticles"));
            @SuppressLint("Range") String content = cursor.getString(cursor.getColumnIndex("content"));

            Article article = new Article(title, idArticles, content);
            articleList.add(article);
        }

        cursor.close();
        db.close();

        return articleList;
    }

    public List<Article> getDetailsArticles() {
        List<Article> articleList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {"author","title", "content","date"};
        Cursor cursor = db.query("articles", columns, null, null, null, null, null);

        while (cursor.moveToNext()) {
            @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex("title"));
            @SuppressLint("Range") String author = cursor.getString(cursor.getColumnIndex("author"));
            @SuppressLint("Range") String content = cursor.getString(cursor.getColumnIndex("content"));
            @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex("date"));

            Article article = new Article(title, author, content,date);
            articleList.add(article);
        }

        cursor.close();
        db.close();

        return articleList;
    }

}
